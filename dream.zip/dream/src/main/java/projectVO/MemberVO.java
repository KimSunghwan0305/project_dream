package projectVO;

public class MemberVO {
    int mem_birth, mem_hp, mem_status;
    String mem_id, mem_pass, mem_name, mem_email1, mem_email2, mem_date;

    public String getMem_date() {
        return mem_date;
    }

    public void setMem_date(String mem_date) {
        this.mem_date = mem_date;
    }

    public int getMem_birth() {
        return mem_birth;
    }

    public void setMem_birth(int mem_birth) {
        this.mem_birth = mem_birth;
    }

    public int getMem_hp() {
        return mem_hp;
    }

    public void setMem_hp(int mem_hp) {
        this.mem_hp = mem_hp;
    }

    public int getMem_status() {
        return mem_status;
    }

    public void setMem_status(int mem_status) {
        this.mem_status = mem_status;
    }

    public String getMem_id() {
        return mem_id;
    }

    public void setMem_id(String mem_id) {
        this.mem_id = mem_id;
    }

    public String getMem_pass() {
        return mem_pass;
    }

    public void setMem_pass(String mem_pass) {
        this.mem_pass = mem_pass;
    }

    public String getMem_name() {
        return mem_name;
    }

    public void setMem_name(String mem_name) {
        this.mem_name = mem_name;
    }

    public String getMem_email1() {
        return mem_email1;
    }

    public void setMem_email1(String mem_email1) {
        this.mem_email1 = mem_email1;
    }

    public String getMem_email2() {
        return mem_email2;
    }

    public void setMem_email2(String mem_email2) {
        this.mem_email2 = mem_email2;
    }

}
